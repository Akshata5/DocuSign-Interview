﻿using System;

namespace DressUp.PresentationServices.Interfaces
{
    public interface IDressUpPresentationService
    {
        void AcceptUserInput(string userInput);
        string GetDressingOrder();
    }
}
