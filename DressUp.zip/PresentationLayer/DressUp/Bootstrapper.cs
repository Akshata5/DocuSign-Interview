﻿using System;
using System.Web.Mvc;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Mvc;
using System.Collections.Generic;
using DressUp.PresentationServices.Interfaces;
using DressUp.PresentationServices;
using DressUp.Business.Services;
using DressUp.Business.Interfaces;
using DressUp.Data.Repository;
using DressUp.Data.Interfaces;

namespace DressUp
{
    public class Bootstrapper
    {
        public static IUnityContainer Initialise()
        {
            var container = new UnityContainer();
            RegisterTypes(container);
            DependencyResolver.SetResolver(new Microsoft.Practices.Unity.Mvc.UnityDependencyResolver(container));
            IDependencyResolver resolver = DependencyResolver.Current;
            IDependencyResolver newResolver = new UnityDependencyResolver(container, resolver);
            DependencyResolver.SetResolver(newResolver);
            return container;
        }

        private static void RegisterTypes(IUnityContainer container)
        {
            container.RegisterType<IDressUpRepository, DressUpRepository>();
            container.RegisterType<IDressUpService, DressUpService>();
            container.RegisterType<IDressUpPresentationService, DressUpPresentationService>();
        }
    }

    public class UnityDependencyResolver : IDependencyResolver
    {
        private IUnityContainer container;
        private IDependencyResolver resolver;

        public UnityDependencyResolver(IUnityContainer container, IDependencyResolver resolver)
        {
            this.container = container;
            this.resolver = resolver;
        }

        public object GetService(Type serviceType)
        {
            try
            {
                return this.container.Resolve(serviceType);
            }
            catch (Exception ex)
            {
                return this.resolver.GetService(serviceType);
            }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            try
            {
                return this.container.ResolveAll(serviceType);
            }
            catch
            {
                return this.resolver.GetServices(serviceType);
            }
        }
    }
}
