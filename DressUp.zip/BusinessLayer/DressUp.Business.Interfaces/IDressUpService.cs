﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DressUp.Business.Interfaces
{
    public interface IDressUpService
    {
        void AcceptUserInput(string userInput);
        string DressUp();
    }
}
