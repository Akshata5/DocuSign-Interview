﻿using System;
using DressUp.Business.Interfaces;
using DressUp.Data.Interfaces;
using System.Text;
using DressUp.Data.Repository;
using DressUp.Data.Models;
using System.Collections.Generic;
using System.Configuration;

namespace DressUp.Business.Services
{
    /// <summary>
    /// Class handling all the business logic of dressing up
    /// </summary>
    public class DressUpService : IDressUpService
    {
        #region Private Fields

        /// <summary>
        /// Variable that holds the underlying layer's class
        /// </summary>
        private IDressUpRepository context;

        /// <summary>
        /// Variable to hold all the commands processed
        /// </summary>
        private List<string> processedCommands;

        /// <summary>
        /// Hot or cold weather dresser class
        /// </summary>
        private IDresser dresser;

        /// <summary>
        /// Variable that holds failure message
        /// </summary>
        private string failureMessage;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor to assign variable with the underlying class' object
        /// </summary>
        /// <param name="objDressUpRepository"></param>
        public DressUpService(IDressUpRepository objDressUpRepository)
        {
            context = objDressUpRepository;
            processedCommands = new List<string>();
            failureMessage = ConfigurationManager.AppSettings["failureMessage"];
        }

        #endregion

        /// <summary>
        /// Accepts user input and stores it in the model
        /// </summary>
        /// <param name="userInput">Input passed by the user</param>
        public void AcceptUserInput(string userInput)
        {
            this.context.AcceptUserInput(userInput);
        }

        /// <summary>
        /// Process the user passed commands
        /// </summary>
        /// <returns>Dressing order</returns>
        public string DressUp()
        {
            //Get the model from the Data layer
            UserInputModel uim = ((DressUpRepository)context).Uim;      //user input model

            //Instantiate dresser based on the first command (weather type) passed by the user
            switch (uim.Input[0].ToUpper())
            {
                case "HOT":
                    dresser = new HotDresser();
                    break;
                case "COLD":
                    dresser = new ColdDresser();
                    break;

                //Invalid weather type
                default:
                    throw new Exception("Invalid weather specified in the first arguement");
            }

            StringBuilder dressingOrder = new StringBuilder(string.Empty);

            try
            {
                //Process all the commands passed by the user (except the first one that would be weather type) and build the dressing order
                for (int i = 1; i < uim.Input.Count; i++)
                {
                    string command = uim.Input[i];

                    //Validate the input command to check compliance with the rules before processing it
                    if (IsValid(command))
                    {
                        //Process the command
                        switch (uim.Input[i])
                        {
                            case "1":
                                dressingOrder.Append(", ").Append(dresser.PutOnFootwear());
                                break;
                            case "2":
                                dressingOrder.Append(", ").Append(dresser.PutOnHeadwear());
                                break;
                            case "3":
                                dressingOrder.Append(", ").Append(dresser.PutOnSocks());
                                break;
                            case "4":
                                dressingOrder.Append(", ").Append(dresser.PutOnShirt());
                                break;
                            case "5":
                                dressingOrder.Append(", ").Append(dresser.PutOnJacket());
                                break;
                            case "6":
                                dressingOrder.Append(", ").Append(dresser.PutOnPants());
                                break;
                            case "7":
                                dressingOrder.Append(", ").Append(dresser.LeaveHouse());
                                break;
                            case "8":
                                dressingOrder.Append(", ").Append(dresser.TakeOffPajamas());
                                break;
                            default:
                                throw new Exception("Invalid weather specified in the first arguement");
                        }
                    }
                   
                    //Add command to processed list of commands
                    processedCommands.Add(command);
                }
            }

            catch (Exception ex)
            {
                //If business rules realted exception (exception message will always be "Fail")
                //append the message with the dressing order and return dressing order
                if (ex.Message == failureMessage)
                {                    
                    return dressingOrder.Append(", ").Append(ex.Message).ToString().Remove(0, 2);       //Remove leading ", " before returning the value
                }

                //Else, throw it back and let the main method handle it
                else
                {
                    throw;
                }
            }

            return dressingOrder.ToString().Remove(0, 2);       //Remove leading ", " before returning the value
        }

        /// <summary>
        /// Validates commands and checks for compliance with the stated rules
        /// </summary>
        /// <param name="command">Command to be validated</param>
        /// <returns>True if the entered command is valid and in compliance with the rules, throws an exception otherwise</returns>
        private bool IsValid(string command)
        {
            #region Generic Checks

            //Pajamas must be taken off before anything else can be put on
            //The first command called should be for removing PJs
            if (processedCommands.Count == 0)
            {                
                if (command != "8")
                {
                    throw new Exception(failureMessage);
                }
            }

            //Only 1 piece of each type of clothing may be put on
            if (processedCommands.Contains(command))
            {
                throw new Exception(failureMessage);
            }

            #endregion

            #region Command-wise Checking

            //You cannot put on socks when it is hot
            //You cannot put on a jacket when it is hot
            if ((command == "3") || (command == "5"))     //If command is for putting on socks or jacket and dresser is of type HotDresser (it is hot)
            {
                if (dresser.GetType() == typeof(HotDresser))
                {
                    throw new Exception(failureMessage);
                }
            }

            //Socks must be put on before shoes
            //Pants must be put on before shoes
            //In other words, if the command is for shoes/footwear, make sure that socks and pants are already put on
            else if (command == "1")
            {
                //if the weather is hot check only for pants
                if (dresser.GetType() == typeof(HotDresser))
                {
                    if (!processedCommands.Contains("6"))
                    {
                        throw new Exception(failureMessage);
                    }
                }                
                //else, check for both socks and pants
                else
                {
                    if (!processedCommands.Contains("3") || !processedCommands.Contains("6"))
                    {
                        throw new Exception(failureMessage);
                    }
                }
            }

            //The shirt must be put on before the headwear or jacket
            //In other words, if the command is for either the headwear or the jacket, make sure that the shirt is already put on
            else if ((command == "2") || (command == "5"))
            {
                if (!processedCommands.Contains("4"))
                {
                    throw new Exception(failureMessage);
                }
            }

            //You cannot leave the house until all items of clothing are on (except socks and a jacket when it’s hot)
            //If the command is for leaving the house, make sure that all the other commands have been processed
            else if (command == "7")
            {
                //Check if jacket and socks are put on only if the weather is hot
                if (dresser.GetType() != typeof(HotDresser))        //weather is not hot
                {
                    if (!processedCommands.Contains("3") || !processedCommands.Contains("5"))       //jacket or shoes/footwear not put on
                    {
                        throw new Exception(failureMessage);
                    }
                }

                //Check for other types of clothing irrespective of the weather type
                if (!processedCommands.Contains("1") || !processedCommands.Contains("2") || !processedCommands.Contains("4") || !processedCommands.Contains("6") || !processedCommands.Contains("8"))
                {
                    throw new Exception(failureMessage);
                }
            }

            #endregion

            //If all the conditions are satisfied, return true
            return true;
        }
    }
}
