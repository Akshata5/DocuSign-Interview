﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DressUp.PresentationServices.ViewModels
{
    public class DressingOrderViewModel
    {
        public string Order { get; set; }
    }
}
