﻿using System;
using DressUp.Business.Interfaces;
using System.Configuration;

namespace DressUp.Business.Services
{
    public class HotDresser : IDresser
    {
        /// <summary>
        /// Variable to hold failure message
        /// </summary>
        private string failureMessage;

        public HotDresser()
        {
            failureMessage = ConfigurationManager.AppSettings["failureMessage"];
        }

        public string PutOnFootwear()
        {
            return "sandals";
        }

        public string PutOnHeadwear()
        {
            return "sun visor";
        }

        public string PutOnSocks()
        {
            throw new Exception(failureMessage);
        }

        public string PutOnShirt()
        {
            return "t-shirt";
        }

        public string PutOnJacket()
        {
            throw new Exception(failureMessage);
        }

        public string PutOnPants()
        {
            return "shorts";
        }

        public string LeaveHouse()
        {
            return "leaving house";
        }

        public string TakeOffPajamas()
        {
            return "Removing PJs";
        }
    }
}
