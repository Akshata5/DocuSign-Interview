﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DressUp.Business.Interfaces
{
    public interface IDresser
    {
        string PutOnFootwear();
        string PutOnHeadwear();
        string PutOnSocks();
        string PutOnShirt();
        string PutOnJacket();
        string PutOnPants();
        string LeaveHouse();
        string TakeOffPajamas();
    }
}
