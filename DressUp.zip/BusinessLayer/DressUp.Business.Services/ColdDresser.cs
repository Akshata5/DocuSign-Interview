﻿using System;
using DressUp.Business.Interfaces;

namespace DressUp.Business.Services
{
    public class ColdDresser : IDresser
    {
        public string PutOnFootwear()
        {
            return "boots";
        }

        public string PutOnHeadwear()
        {
            return "hat";
        }

        public string PutOnSocks()
        {
            return "socks";
        }

        public string PutOnShirt()
        {
            return "shirt";
        }

        public string PutOnJacket()
        {
            return "jacket";
        }

        public string PutOnPants()
        {
            return "pants";
        }

        public string LeaveHouse()
        {
            return "leaving house";
        }

        public string TakeOffPajamas()
        {
            return "Removing PJs";
        }
    }
}
