﻿using System;
using DressUp.Data.Interfaces;
using DressUp.Data.Models;
using System.Collections.Generic;

namespace DressUp.Data.Repository
{
    /// <summary>
    /// Repository handling all the data access logic
    /// </summary>
    public class DressUpRepository : IDressUpRepository
    {
        /// <summary>
        /// Instance of UserInputModel
        /// </summary>
        public UserInputModel Uim;      //user input model

        /// <summary>
        /// Accepts user input and stores it in the model
        /// </summary>
        /// <param name="userInput">Input passed by the user</param>
        public void AcceptUserInput(string userInput)
        {
            Uim = new UserInputModel();

            //Removing spaces and commas from the input
            string[] userInputArray = userInput.Split(',', ' ');

            Uim.Input = new List<string>();

            //Store all the input commands passed by the user in the data model, one-by-one
            foreach (string input in userInputArray)
            {
                if (input.Trim() != string.Empty)
                {
                    Uim.Input.Add(input);
                }
            }
        }
    }
}
