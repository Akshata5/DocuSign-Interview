﻿using System;
using DressUp.PresentationServices.Interfaces;
using DressUp.Business.Interfaces;
using DressUp.PresentationServices.ViewModels;

namespace DressUp.PresentationServices
{
    public class DressUpPresentationService : IDressUpPresentationService
    {
        private IDressUpService context;
        DressingOrderViewModel dressingOrder;

        public DressUpPresentationService (IDressUpService objDressUpService)
	    {
            this.context = objDressUpService;
	    }

        public void AcceptUserInput(string userInput)
        {
            this.context.AcceptUserInput(userInput);
        }

        private void DressUp()
        {
            dressingOrder = new DressingOrderViewModel();
            dressingOrder.Order = this.context.DressUp();
        }

        public string GetDressingOrder()
        {
            DressUp();
            return dressingOrder.Order;
        }
    }
}
