﻿using System;
using System.Web.Mvc;
using DressUp.PresentationServices.Interfaces;

namespace DressUp.Presentation
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Initialize Bootstrapper for dependency injection
                Bootstrapper.Initialise();

                //Get context (from PresentationServicesLayer)
                IDressUpPresentationService context = DependencyResolver.Current.GetService<IDressUpPresentationService>();

                //Accept user input
                Console.Write("Input: ");
                string input = Console.ReadLine();                
                context.AcceptUserInput(input);

                //Display result
                Console.Write("Output: {0}", context.GetDressingOrder());
                Console.ReadLine();
            }

            //Handle general exceptions
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
            }
        }
    }
}
