﻿using System;

namespace DressUp.Data.Interfaces
{
    /// <summary>
    /// Interface with methods for data access
    /// </summary>
    public interface IDressUpRepository
    {
        /// <summary>
        /// Accepts user input and stores it in the model
        /// </summary>
        /// <param name="userInput">Input passed by the user</param>
        void AcceptUserInput(string userInput);
    }
}
